import { NominatimProvider } from "./nominatimProvider";
import type { GeocodingProvider } from "./types";

export type { GeocodingProvider } from "./types";
export { GeocodingError } from "./types";

/**
 * Provider selection point. Today only the free OSM/Nominatim provider is
 * implemented. A future `GOOGLE` option would live here behind the same
 * interface — see README "Map & geocoding" for the cost tradeoffs.
 */
function createGeocodingProvider(): GeocodingProvider {
  return new NominatimProvider();
}

export const geocodingProvider = createGeocodingProvider();
