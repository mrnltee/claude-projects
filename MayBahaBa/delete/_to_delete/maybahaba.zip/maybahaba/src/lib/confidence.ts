import {
  CONFIDENCE_AGREEMENT_SEVERITY_TOLERANCE,
  CONFIDENCE_THRESHOLDS,
} from "./config/confidence";
import { getFreshness } from "./freshness";
import { getFloodDepthOption, type ConfidenceResult, type FloodReport } from "./types";

/**
 * Community-validation confidence (spec section 16/34).
 *
 * V1 formula: count non-expired, non-denied reports near the same location
 * whose flood-depth severity roughly agrees with the top (most recent)
 * report. More agreeing reports → higher confidence. This is deliberately
 * simple; the shape leaves room for weighting by validation count,
 * reporter history, etc. later without changing the public API.
 */
export function computeConfidence(
  topReport: FloodReport | null,
  nearbyReports: FloodReport[],
  now: Date = new Date()
): ConfidenceResult {
  if (!topReport) return { level: "NONE", agreeingReportCount: 0 };

  const topSeverity = getFloodDepthOption(topReport.floodDepth).severity;

  const agreeing = nearbyReports.filter((r) => {
    if (getFreshness(r.reportedAt, now).level === "EXPIRED") return false;
    if (r.status === "DENIED") return false;
    const severity = getFloodDepthOption(r.floodDepth).severity;
    return Math.abs(severity - topSeverity) <= CONFIDENCE_AGREEMENT_SEVERITY_TOLERANCE;
  });

  // Validated reports count extra toward agreement, capped so one busy
  // validator can't dominate the score.
  const weighted = agreeing.reduce((sum, r) => sum + (r.status === "VALIDATED" ? 1.5 : 1), 0);

  let level: ConfidenceResult["level"];
  if (weighted >= CONFIDENCE_THRESHOLDS.HIGH_MIN_AGREEING_REPORTS) level = "HIGH";
  else if (weighted >= CONFIDENCE_THRESHOLDS.MEDIUM_MIN_AGREEING_REPORTS) level = "MEDIUM";
  else level = "LOW";

  return { level, agreeingReportCount: agreeing.length };
}
