import { FRESHNESS_LABELS, FRESHNESS_THRESHOLDS_MINUTES } from "./config/freshness";
import type { FreshnessResult } from "./types";

/** Computes the freshness tier of a report relative to `now` (spec section 17). */
export function getFreshness(reportedAtIso: string, now: Date = new Date()): FreshnessResult {
  const minutesAgo = Math.max(
    0,
    Math.round((now.getTime() - new Date(reportedAtIso).getTime()) / 60000)
  );

  const t = FRESHNESS_THRESHOLDS_MINUTES;
  let level: FreshnessResult["level"];
  if (minutesAgo <= t.VERY_RECENT_MAX) level = "VERY_RECENT";
  else if (minutesAgo <= t.RECENT_MAX) level = "RECENT";
  else if (minutesAgo <= t.AGING_MAX) level = "AGING";
  else if (minutesAgo <= t.STALE_MAX) level = "STALE";
  else level = "EXPIRED";

  return { level, minutesAgo, label: FRESHNESS_LABELS[level] };
}

export function isExpired(reportedAtIso: string, now: Date = new Date()): boolean {
  return getFreshness(reportedAtIso, now).level === "EXPIRED";
}
