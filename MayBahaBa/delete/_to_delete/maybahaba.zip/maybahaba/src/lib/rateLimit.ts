import { createHash } from "crypto";

/**
 * Minimal in-memory rate limiter (spec section 23/46).
 *
 * Good enough for a single-instance MVP deployment. On a multi-instance
 * serverless platform each instance has its own counters, so this is a
 * soft limit, not a hard guarantee — call out in README that a shared
 * store (e.g. Upstash Redis free tier) is the natural upgrade path.
 */

interface Bucket {
  count: number;
  windowStartMs: number;
}

const buckets = new Map<string, Bucket>();

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  retryAfterSeconds: number;
}

export function rateLimit(key: string, limit: number, windowSeconds: number): RateLimitResult {
  const now = Date.now();
  const windowMs = windowSeconds * 1000;
  const existing = buckets.get(key);

  if (!existing || now - existing.windowStartMs >= windowMs) {
    buckets.set(key, { count: 1, windowStartMs: now });
    return { allowed: true, remaining: limit - 1, retryAfterSeconds: 0 };
  }

  if (existing.count >= limit) {
    const retryAfterSeconds = Math.ceil((existing.windowStartMs + windowMs - now) / 1000);
    return { allowed: false, remaining: 0, retryAfterSeconds };
  }

  existing.count += 1;
  return { allowed: true, remaining: limit - existing.count, retryAfterSeconds: 0 };
}

/**
 * Hashes an identifying value (IP address, etc.) so raw values are never
 * stored or logged (spec section 23: "IP hashing rather than storing raw
 * IP addresses").
 */
export function hashIdentifier(value: string): string {
  const salt = process.env.ABUSE_HASH_SALT ?? "maybahaba-dev-salt";
  return createHash("sha256").update(`${salt}:${value}`).digest("hex").slice(0, 32);
}

/** Best-effort client identifier from request headers, for rate limiting only. */
export function getClientKey(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for");
  const ip = forwarded ? forwarded.split(",")[0].trim() : "unknown";
  return hashIdentifier(ip);
}
