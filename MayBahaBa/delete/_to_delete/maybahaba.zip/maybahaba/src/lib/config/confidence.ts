/**
 * Community-validation confidence tiers (spec section 16 / 34).
 *
 * The real formula is intentionally simple for V1 and lives only here so
 * it can grow (validation weight, reporter history, contradiction
 * penalties, etc.) without touching call sites.
 */
export const CONFIDENCE_THRESHOLDS = {
  /** Agreeing recent reports required for "High confidence". */
  HIGH_MIN_AGREEING_REPORTS: 4,
  /** Agreeing recent reports required for "Medium confidence". */
  MEDIUM_MIN_AGREEING_REPORTS: 2,
} as const;

/**
 * Two reports "agree" if their flood-depth severity differs by at most
 * this many steps (see FLOOD_DEPTH_OPTIONS severity in lib/types.ts).
 */
export const CONFIDENCE_AGREEMENT_SEVERITY_TOLERANCE = 1;
