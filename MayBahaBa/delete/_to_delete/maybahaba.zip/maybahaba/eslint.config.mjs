import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";

const eslintConfig = defineConfig([
  ...nextVitals,
  ...nextTs,
  {
    rules: {
      // The React Compiler's "no setState synchronously in an effect"
      // check is stricter than the standard, docs-endorsed
      // loading/error/data fetching pattern used throughout this app's
      // components (SearchBox, the admin validation queue, etc.) — set
      // loading, kick off a fetch, set the result when it resolves.
      // Every such effect here already guards against races (request-id
      // refs) and cleans up. Kept as a warning rather than disabled
      // outright so genuinely avoidable cases still get flagged.
      "react-hooks/set-state-in-effect": "warn",
    },
  },
  // Override default ignores of eslint-config-next.
  globalIgnores([
    // Default ignores of eslint-config-next:
    ".next/**",
    "out/**",
    "build/**",
    "next-env.d.ts",
  ]),
]);

export default eslintConfig;
